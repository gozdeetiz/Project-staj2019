package net.codejava;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SistemRepository extends JpaRepository<Personel,Long>{
	

}
